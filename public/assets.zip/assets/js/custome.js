$(document).ready(function(){
    
    // cuurent city section
     $(".image-radio").on("click", function(e){
        $(".image-radio").removeClass('rightcuntry');
        $(this).addClass('rightcuntry');
        var $radio = $(this).find('input[type="radio"]');
        $radio.prop("checked",!$radio.prop("checked"));

        e.preventDefault();
    });
    
    
})



// js for Header Fixed Ajeet * //

$(function() {
    var nav = $(".statichdr");
    $(window).scroll(function() {    
        var scroll = $(window).scrollTop();
    
        if (scroll >= 90) {
            nav.removeClass('statichdr').addClass("navfixed");
        } else {
            nav.removeClass("navfixed").addClass('statichdr');
        }
    });
});


// js for open menu Ajeet *//

$(".toggledivmen").click(function (e) {
    e.stopPropagation();
    $(".menu-section").toggleClass('new-opns');
});

$(".toggledivmen").click(function (e) {
    e.stopPropagation();
    $(".toggledivmen").toggleClass('cross');
});


$(".userprofile").click(function (e) {
    e.stopPropagation();
    $(".userlistingopn").toggleClass('openpanel');
});

$("body").click(function (e) {
    e.stopPropagation();
    $(".userlistingopn").removeClass('openpanel');
});





// js for More Page Tabs *//


function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

// js for profile edits //

var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var profilepanel = this.nextElementSibling;
    if (profilepanel.style.maxHeight){
      profilepanel.style.maxHeight = null;
    } else {
      profilepanel.style.maxHeight = profilepanel.scrollHeight + "px";
    } 
  });
}